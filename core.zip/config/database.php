<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'appliances_db');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');