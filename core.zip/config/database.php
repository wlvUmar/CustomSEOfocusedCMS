<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'kuplyuta_db');
define('DB_USER', 'kuplyuta_admin');
define('DB_PASS', '=@iX?z~gukWg');
define('DB_CHARSET', 'utf8mb4');